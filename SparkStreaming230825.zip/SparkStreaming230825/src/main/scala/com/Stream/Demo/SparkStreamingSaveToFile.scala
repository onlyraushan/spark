package com.Stream.Demo
package com.Stream.Demo

object SparkStreamingSaveToFile {

}
